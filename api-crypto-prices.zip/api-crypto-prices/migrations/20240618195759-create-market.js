'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Market', {
      ID_Market: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      Country: {
        type: Sequelize.STRING(100),
        allowNull: false
      },
      NameMarket: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      Location: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      ID_Exchange: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Exchange',
          key: 'ID_Exchange'
        },
        allowNull: true,
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Market');
  }
};

