'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('PriceAlert', {
      ID_Alert: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      PriceTarget: {
        type: Sequelize.DECIMAL(18, 2),
        allowNull: false
      },
      DateCreated: {
        allowNull: false,
        type: Sequelize.DATE
      },
      ID_User: {
        type: Sequelize.INTEGER,
        references: {
          model: 'User',
          key: 'ID_User'
        },
        allowNull: false,
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      ID_Crypto: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Cryptocurrency',
          key: 'ID_Crypto'
        },
        allowNull: false,
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('PriceAlert');
  }
};

