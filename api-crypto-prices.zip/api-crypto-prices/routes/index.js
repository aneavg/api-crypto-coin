const express = require('express');
const router = express.Router();

const cryptocurrencyRoutes = require('./cryptocurrencyRoutes');

router.use(cryptocurrencyRoutes);

module.exports = router;
