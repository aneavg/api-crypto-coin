const express = require('express');
const router = express.Router();
const Cryptocurrency = require('../models/cryptocurrency');

router.get('/cryptocurrencies', async (req, res) => {
  try {
    const cryptocurrencies = await Cryptocurrency.findAll();
    res.json(cryptocurrencies);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

module.exports = router;
