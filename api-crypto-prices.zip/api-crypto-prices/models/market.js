const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Market = sequelize.define('Market', {
  ID_Market: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  Country: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  NameMarket: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  Location: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
}, {
  timestamps: true,
});

module.exports = Market;
