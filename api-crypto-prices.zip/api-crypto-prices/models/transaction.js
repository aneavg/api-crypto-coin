const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./user');
const Market = require('./market');
const Cryptocurrency = require('./cryptocurrency');
const Exchange = require('./exchange');

const Transaction = sequelize.define('Transaction', {
  ID_Trans: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  Quantity: {
    type: DataTypes.DECIMAL(18, 8),
    allowNull: false,
  },
  Type: {
    type: DataTypes.ENUM('Buy', 'Sell'),
    allowNull: false,
  },
  TimeDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  ID_User: {
    type: DataTypes.INTEGER,
    references: {
      model: User,
      key: 'ID_User',
    },
    allowNull: false,
  },
  ID_Market: {
    type: DataTypes.INTEGER,
    references: {
      model: Market,
      key: 'ID_Market',
    },
    allowNull: false,
  },
  ID_Crypto: {
    type: DataTypes.INTEGER,
    references: {
      model: Cryptocurrency,
      key: 'ID_Crypto',
    },
    allowNull: false,
  },
  ID_Exchange: {
    type: DataTypes.INTEGER,
    references: {
      model: Exchange,
      key: 'ID_Exchange',
    },
    allowNull: true,
  },
}, {
  timestamps: true,
});

module.exports = Transaction;
