const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Cryptocurrency = require('./cryptocurrency');
const Market = require('./market');

const PriceHistory = sequelize.define('PriceHistory', {
  ID_Hist: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  Price: {
    type: DataTypes.DECIMAL(18, 2),
    allowNull: false,
  },
  TimeDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  ID_Crypto: {
    type: DataTypes.INTEGER,
    references: {
      model: Cryptocurrency,
      key: 'ID_Crypto',
    },
    allowNull: false,
  },
  ID_Market: {
    type: DataTypes.INTEGER,
    references: {
      model: Market,
      key: 'ID_Market',
    },
    allowNull: false,
  },
}, {
  timestamps: false,
});

module.exports = PriceHistory;
