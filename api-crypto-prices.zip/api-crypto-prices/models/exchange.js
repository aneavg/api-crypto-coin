const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Exchange = sequelize.define('Exchange', {
  ID_Exchange: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  Name: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  Country: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  ExchangeRate: {
    type: DataTypes.DECIMAL(18, 8),
    allowNull: false,
  },
}, {
  timestamps: true,
});

module.exports = Exchange;
