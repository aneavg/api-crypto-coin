const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./user');
const Cryptocurrency = require('./cryptocurrency');

const PriceAlert = sequelize.define('PriceAlert', {
  ID_Alert: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  PriceTarget: {
    type: DataTypes.DECIMAL(18, 2),
    allowNull: false,
  },
  DateCreated: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  ID_User: {
    type: DataTypes.INTEGER,
    references: {
      model: User,
      key: 'ID_User',
    },
    allowNull: false,
  },
  ID_Crypto: {
    type: DataTypes.INTEGER,
    references: {
      model: Cryptocurrency,
      key: 'ID_Crypto',
    },
    allowNull: false,
  },
}, {
  timestamps: false,
});

module.exports = PriceAlert;
