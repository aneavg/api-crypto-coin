
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Cryptocurrency = sequelize.define('Cryptocurrency', {
  ID_Crypto: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  Name: {
    type: DataTypes.STRING(255),
  },
  Symbol: {
    type: DataTypes.STRING(10),
  },
});

module.exports = Cryptocurrency;
